import time

import numpy as np
from keras import Input
from keras.callbacks import LearningRateScheduler
from keras.layers import Dense, Flatten, Dropout, Concatenate
from keras.layers.convolutional import Conv1D, MaxPooling1D
from keras.layers.normalization import BatchNormalization
from keras.models import Model
from keras.optimizers import Adam
from keras.utils import multi_gpu_model
from sklearn.preprocessing import StandardScaler

from evaluate_ensemble import find_accuracy
from tcn_model import dilated_tcn as tcn

NUM_MON_SITES = 100
NUM_MON_INST_TEST = 30
NUM_MON_INST_TRAIN = 60
NUM_MON_INST = NUM_MON_INST_TEST + NUM_MON_INST_TRAIN
NUM_UNMON_SITES_TEST = 5500
NUM_UNMON_SITES_TRAIN = 3500
NUM_UNMON_SITES = NUM_UNMON_SITES_TEST + NUM_UNMON_SITES_TRAIN

seq_length = 4096


def time_conv_layer(model, nb_filters):
    """Conv-ReLU-Batch Normalization layer for timing. This does not use dilated convolutions."""

    model = Conv1D(filters=nb_filters, kernel_size=3, padding='causal', activation='relu')(model)
    model = BatchNormalization()(model)
    return model


def time_conv_block(model, nb_layers, nb_filters):
    """Creates multiple conv layers followed by max pooling and dropout layers."""

    for _ in range(nb_layers):
        model = time_conv_layer(model, nb_filters)
    model = MaxPooling1D()(model)
    model = Dropout(0.1)(model)
    return model


def dense_layer(model, units, drop_rate):
    """Fully-connected-ReLU-Batch Normalization-Dropout layer."""

    model = Dense(units=units, activation='relu')(model)
    model = BatchNormalization()(model)
    model = Dropout(drop_rate)(model)
    return model


def lr_scheduler(epochs):
    """Multiplies learning rate by 0.1 at 100 and 150 epochs, i.e.,
    new learning rate = old learning rate * 0.1"""

    switch_points = [0, 99, 149]
    for i in [2, 1, 0]:
        if epochs >= switch_points[i]:
            return 0.001 * pow(0.1, i)


def tcn_train():
    data_dir = "/home/liyanzeng/git/tcn_exp/preprocess_wang"

    # read in data from numpy files
    train_metadata = np.load(r"%s/train_metadata.npy" % data_dir)
    test_metadata = np.load(r"%s/test_metadata.npy" % data_dir)
    train_seq = np.load(r"%s/train_seq.npy" % data_dir)
    train_labels = np.load(r"%s/train_labels.npy" % data_dir)
    test_seq = np.load(r"%s/test_seq.npy" % data_dir)
    test_labels = np.load(r"%s/test_labels.npy" % data_dir)
    # apply normalization to metadata
    metadata_scaler = StandardScaler()
    train_metadata = metadata_scaler.fit_transform(train_metadata)
    test_metadata = metadata_scaler.transform(test_metadata)

    # extract sequences
    train_time, train_time_dleft, train_time_dright, train_dir = np.split(train_seq, 4, axis=2)
    test_time, test_time_dleft, test_time_dright, test_dir = np.split(test_seq, 4, axis=2)

    train_time = np.reshape(train_time, (train_time.shape[0], train_time.shape[1]))
    test_time = np.reshape(test_time, (test_time.shape[0], test_time.shape[1]))

    train_dir, test_dir = np.reshape(train_dir, (train_dir.shape[0], train_dir.shape[1])), np.reshape(test_dir, (
    test_dir.shape[0], test_dir.shape[1]))
    print(train_dir.shape, train_time.shape)

    time_scaler = StandardScaler()
    train_time = time_scaler.fit_transform(train_time)
    test_time = time_scaler.transform(test_time)

    # Stack direction and time features 
    train_seq = np.stack((train_dir, train_time), axis=-1)
    test_seq = np.stack((test_dir, test_time), axis=-1)

    # construct TCN model
    tcn_input = Input(shape=(seq_length, 2,), name='cnn_input')
    tcn_output = tcn(input=tcn_input, kernel_size=8, num_classes=1024,
                     dilatations=[1, 2, 4, 8], nb_filters=24,
                     nb_stacks=16, activation='norm_relu')
    print(tcn_input.shape, tcn_output.shape)
    
    
    metadata_input = Input(shape=(7,), name='metadata_input')
    metadata_output = dense_layer(metadata_input, 32, 0.)  # consider this the embedding of all the metadata

    # with metadata
    # combined = Concatenate()([tcn_output, metadata_output])
    # combined = dense_layer(combined, 1024, 0.5)

    # actually w/o metadata also worked well
    combined = dense_layer(tcn_output, 1024, .5)

    # add final softmax layer
    if NUM_UNMON_SITES == 0:  # closed-world
        combined_output = Dense(units=NUM_MON_SITES, activation='softmax', name='combined_output')(combined)
    else:
        # add extra class for unmonitored sites
        combined_output = Dense(units=NUM_MON_SITES + 1, activation='softmax', name='combined_output')(combined)

    model = Model(inputs=[tcn_input, metadata_input], outputs=[combined_output])

    # Multi gpu
    model = multi_gpu_model(model, 2)
    model.compile(loss='categorical_crossentropy',
                  optimizer=Adam(0.001),
                  metrics=['accuracy'])

    training_data = ({'cnn_input': train_seq,
                      'metadata_input': train_metadata},
                     {'combined_output': train_labels})

    test_data = ({'cnn_input': test_seq,
                  'metadata_input': test_metadata},
                 {'combined_output': test_labels})

    lr_modifier = LearningRateScheduler(schedule=lr_scheduler)

    # train model
    train_time_start = time.time()
    model.fit(x=training_data[0],
              y=training_data[1],
              batch_size=50,
              epochs=80,
              verbose=1,
              callbacks=[lr_modifier],
              validation_split=1/7)
    train_time_end = time.time()

    # compute final softmax predictions on test set and save predictions
    test_time_start = time.time()
    predictions = model.predict(test_data[0], batch_size=50, verbose=0)
    test_time_end = time.time()

    save_dir = "predictions"
    np.save(file=r"%s/dir_model" % save_dir, arr=predictions)

    return (train_time_end - train_time_start), (test_time_end - test_time_start)


def evaluate():
    prediction_dir = "/home/liyanzeng/git/tcn_exp/predictions"
    data_dir = "/home/liyanzeng/git/tcn_exp/preprocess"

    # read in data from numpy files
    dir_predictions = np.load(r"%s/dir_model.npy" % prediction_dir)
    test_labels = np.load(r"%s/test_labels.npy" % data_dir)
    print("dir model results:" + find_accuracy(dir_predictions, test_labels, 0.) + '\n')


def main(num_mon_sites, num_mon_inst_test, num_mon_inst_train, num_unmon_sites_test, num_unmon_sites_train):
    global NUM_MON_SITES
    global NUM_MON_INST_TEST
    global NUM_MON_INST_TRAIN
    global NUM_MON_INST
    global NUM_UNMON_SITES_TEST
    global NUM_UNMON_SITES_TRAIN
    global NUM_UNMON_SITES

    NUM_MON_SITES = num_mon_sites
    NUM_MON_INST_TEST = num_mon_inst_test
    NUM_MON_INST_TRAIN = num_mon_inst_train
    NUM_MON_INST = num_mon_inst_test + num_mon_inst_train
    NUM_UNMON_SITES_TEST = num_unmon_sites_test
    NUM_UNMON_SITES_TRAIN = num_unmon_sites_train
    NUM_UNMON_SITES = num_unmon_sites_test + num_unmon_sites_train

    print("running dir model")
    time_train_dir_model, time_test_dir_model = tcn_train()
    evaluate()


if __name__ == '__main__':
    main(100, 30, 60, 0, 0)
